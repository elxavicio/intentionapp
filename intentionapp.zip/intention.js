if (confirm(`Are you sure you want to spend time on ${window.location.hostname}`)) {
    alert(`I'm so disappointed`);
  } else {
    alert(`I'm proud of you!`);
    window.location = 'http://www.donothingfor2minutes.com/';
  } 