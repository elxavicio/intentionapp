# Intention App
Intentionapp is a brower extension that helps you be more aware on why you are accessing addictive tools like social media from your browser.

Inspired by the conversation between Jocelyn K. Glei and Cal Newport (https://hurryslowly.co/cal-newport/).
